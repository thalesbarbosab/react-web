import React, { Component } from 'react'

class New extends Component {
  render() {
    return (
      <h1>New</h1>
    )
  }
}

export default New